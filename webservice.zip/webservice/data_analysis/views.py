from django.shortcuts import get_object_or_404, render

from data_analysis.models import Company


def index(request):
    company_list = Company.objects.all()
    context = {'company_list': company_list}
    return render(request, 'data_analysis/index.html', context)
    
def company_detail(request, company_id):
    company = get_object_or_404(Company, pk=company_id)
    return render(request, 'data_analysis/company_detail.html', {'company': company})
